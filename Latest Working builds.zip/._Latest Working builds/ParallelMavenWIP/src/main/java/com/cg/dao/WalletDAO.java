package com.cg.dao;

import java.util.*;

import com.cg.dto.*;


public interface WalletDAO 
{
    public List<Customer> findAll(); 
    public Customer findById(String id);
	public Customer findByMob(String mobileNo);
    public void create(Customer customer);
    public void update(Customer customer);
    public void deposit(float amount, String id);
    public void withdraw(float amount, String id);
    public void transfer(float amount, String idfrom, String mobNo);
    public void addToHist(History history);
    public List<History> showHist(String mobNo);
}