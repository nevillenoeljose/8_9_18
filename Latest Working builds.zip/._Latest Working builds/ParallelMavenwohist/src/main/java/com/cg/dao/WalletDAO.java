package com.cg.dao;

import java.util.*;

import com.cg.dto.*;


public interface WalletDAO 
{
    public List<Customer> findAll(); 
    public Customer findById(int id);
	public Customer findByMob(String mobileNo);
    public void create(Customer customer);
    public void update(Customer customer);
    public void delete(String[] ids);
    public void deposit(float amount, int id);
    public void withdraw(float amount, int id);
    public void transfer(float amount, int idfrom, String mobNo);
    public void addToHist(History history);
    public List<History> showHist(String mobNo);
}