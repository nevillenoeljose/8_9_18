package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "customersnew")
public class Customer {
	
	
	@Transient
	private int id;
	
    @Id
	@NotEmpty(message="Field cannot be empty") 
	@Size(min = 10, max = 10, message="Please enter a valid 10 digit mobile number!")
	@Column(name="mobileNo")
	private String mobileNo;
	
	@NotEmpty(message="Field cannot be empty") 
	@Size(min = 3, message="Name must be atleast 3 characters long")
	@Column(name="name")
	private String name;
	
	@Min(value=0, message="Starting balance must be positive")
	@Column(name="balance")
	private float balance;
	
	// Default constructor
	public Customer() {
		super();
        id=-1;
		mobileNo=name="";
		balance=0;
	}
	
	// Parameterized Constructor
	public Customer(String name, String mobileNo, float balance) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}
	
	// Getters and Setters 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}

	// To String method for Customer object
	@Override
	public String toString() {
		return "\n" + "Customer name=" + name + ", Mobile Num=" + mobileNo
				 + ", Balance= " + balance ;
	}
	
}
