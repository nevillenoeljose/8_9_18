package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "Historynew")
public class History {
	
//	@GeneratedValue(strategy=GenerationType.AUTO)
//  @Column(name="ID")
	@Id
	@Column(name="time")
	String time;
	
	@Transient
	private int id;
	
	@Column(name="histMobileNo")
	String histMobileNo;
	
	@Column(name="operation")
	String operation;
	
	@Column(name="histAmount")
	float histAmount;
	
	// Default constructor
	public History() {

	}
	
	// Parameterized Constructor
	public History(String histmobileno, String operation, float histamount, String time) {
		this.histMobileNo = histmobileno;
		this.operation = operation;
		this.histAmount = histamount;
		this.time = time;
	}
	
	// To String method for Customer object
	@Override
	public String toString() {
		return "\n" + "Number=" + histMobileNo + ", Operation Number=" + operation
				 + ", Transaction Amount= " + histAmount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getHistMobileNo() {
		return histMobileNo;
	}

	public void setHistMobileNo(String histMobileNo) {
		this.histMobileNo = histMobileNo;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public float getHistAmount() {
		return histAmount;
	}

	public void setHistAmount(float histAmount) {
		this.histAmount = histAmount;
	}
	
	// Getters and Setters 
	
	
		
}
