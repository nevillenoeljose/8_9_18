package com.cg.service;

import java.util.List;

import com.cg.dto.Customer;
import com.cg.dto.History;
import com.cg.exceptions.InputException;

public interface ServiceDAO {
	public List<Customer> findAll(); 
    public Customer findById(String id);
	public Customer findByMob(String mobileNo);
    public void create(Customer customer);
    public void update(Customer customer);
    public void deposit(float amount, String id);
    public void withdraw(float amount, String id);
    public void transfer(float amount, String idfrom, String mobNo);
    public void addToHist(History history);
    public List<History> showHist(String mobNo);
    public boolean validateWithdraw(String mobileNo, float amount) throws InputException;
    public boolean validateDeposit(String mobileNo, float amount) throws InputException;
    public boolean validateTransfer(String mobileNoFrom, String mobileNoTo, float amount) throws InputException;
    public boolean validateNumber(String mobileNo) throws InputException;
}
